package implementations;

import interfaces.Mail;

public class SMTPSaver implements Runnable {

	private Mail mailObject;

	public SMTPSaver(Mail mail) {
		mailObject = mail;
	}

	public SMTPSaver()
	{
		// TODO Auto-generated constructor stub
	}

	private void saveMailLocally() {
		//Logic to save the mail locally will be written during POP3 implementation
	}

	@Override
	public void run() {
		saveMailLocally();
	}

}
