package implementations;

import interfaces.MailProcessor;
import interfaces.NetworkInteractor;

import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import constants.MailServerConstants;

public class MailServer
{

	private static NetworkInteractor			interactor;
	private static MailProcessor				mailProcessor;
	private static HashMap< String, String >	propertyValueMap	= new HashMap< String, String >();
	private static ExecutorService				executorService;
	
	public static void initialize()
	{
		propertyValueMap = SMTPServerHelper.loadProperties();
		executorService = Executors.newFixedThreadPool( Integer.parseInt( propertyValueMap.get( "THREAD_COUNT" ) ) );
		interactor = new SocketNetworkInteractor();
		mailProcessor = new SMTPMailProcessor();
		mailProcessor.initialize();
		new MailServerConstants();

	}

	public static ExecutorService getExecutorService()
	{
		return executorService;
	}

	public static NetworkInteractor getInteractor()
	{
		return interactor;
	}

	public static MailProcessor getMailProcessor()
	{
		return mailProcessor;
	}

	public static void main( String[] args )
	{
		initialize();
		interactor.startServer();
	}

}
