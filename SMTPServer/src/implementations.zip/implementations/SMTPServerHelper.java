package implementations;

import interfaces.MailHelper;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;

import constants.MailServerConstants;

public class SMTPServerHelper implements MailHelper
{

	public static String getResponseLine( int defaultSuccessCode, String msg )
	{
		return defaultSuccessCode + " " + msg;
	}

	public static boolean userExist( String user )
	{
		// To be implemented after User Account Management
		return true;
	}

	public static ArrayList< String > getKeywordClasses()
	{
		LinkedHashMap< String, String > keywordClassMap = new LinkedHashMap< String, String >();
		try
		{
			SMTPServerHelper helper = new SMTPServerHelper();
			
			BufferedReader reader = new BufferedReader( new InputStreamReader(helper.getClass().getClassLoader().getResourceAsStream(MailServerConstants.KEYWORD_CONF_FILE)) );
			String line = null;

			while ( ( line = reader.readLine() ) != null )
			{
				if ( line.matches( "^##.*" ) )
				{
					String[] args = line.split( "##" );
					keywordClassMap.put( args[ 1 ], args[ 2 ] );
				}
			}

		}
		catch ( FileNotFoundException e )
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch ( IOException e )
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return new ArrayList<String> (keywordClassMap.values());
	}

	public static String getDomain( String address )
	{
		address.replaceFirst( "<(.*)>", "$1" );
		String[] addressArray = address.split( "@", 2 );
		return addressArray[ 1 ];
	}

	public static ArrayList< String > tokenize( String line )
	{
		String[] parArray = line.split( " ", 2 );
		ArrayList< String > tokens = new ArrayList< String >( Arrays.asList( parArray ) );
		return tokens;
	}
	
	public static HashMap< String, String > loadProperties() {
		
		HashMap< String, String > propertyValueMap = new HashMap< String, String >();
		try
		{
			SMTPServerHelper helper = new SMTPServerHelper();
			ClassLoader cL = helper.getClass().getClassLoader();
			InputStream ip = cL.getResourceAsStream(MailServerConstants.PROPERTIES_FILE);
			
			
			BufferedReader reader = new BufferedReader( new InputStreamReader(helper.getClass().getClassLoader().getResourceAsStream(MailServerConstants.PROPERTIES_FILE)) );
			String line = null;

			while ( ( line = reader.readLine() ) != null )
			{	
				String[] args = line.split( ":" );
				propertyValueMap.put( args[ 0 ], args[ 1 ] );
			}
		}
		catch ( FileNotFoundException e )
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch ( IOException e )
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return propertyValueMap;
		
		
		
	}

}
