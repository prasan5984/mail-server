package implementations;

import implementations.keywords.properties.SMTPProperties;
import interfaces.Keyword;
import interfaces.Mail;
import interfaces.MailHandler;
import interfaces.MailHelper;
import interfaces.MailProcessor;
import interfaces.NetworkInteractor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;

public class SMTPSender implements MailHandler, Runnable
{

	private Mail									mail;
	protected static ArrayList< SMTPProperties >	keywordPropertySequence	= new ArrayList< SMTPProperties >();
	public static LinkedHashMap< String, Keyword >	keywordMap				= new LinkedHashMap< String, Keyword >();
	private int										keywordIndex			= 0;
	private SMTPProperties							currentProperty;
	private Keyword									currentKeyword;
	private static MailProcessor					mailProcessor;
	private Object									conId;

	SMTPSender( Mail mailObj )
	{
		mail = mailObj;
	}

	public SMTPSender()
	{
		// TODO Auto-generated constructor stub
	}

	public void initialize()
	{
		mailProcessor = MailServer.getMailProcessor();
		keywordMap = mailProcessor.getKeywordMap();
		setPropertySequence( keywordMap.values() );

	}

	private void setPropertySequence( Collection< Keyword > keys )
	{
		Iterator< Keyword > i = keys.iterator();

		while ( i.hasNext() )
		{
			Keyword key = i.next();
			keywordPropertySequence.add( (SMTPProperties)key.getProperties() );
		}

	}

	public String processMailTransaction( String response )
	{
		if ( currentProperty != null /*&& ( !currentProperty.isMultiOccurence() )*/ && currentKeyword.getStatus() )
			keywordIndex++;
		currentProperty = keywordPropertySequence.get( keywordIndex );
		currentKeyword = keywordMap.get( currentProperty.getKeywordName() );

		String msg = currentKeyword.getMailTransaction( mail , response );

		mailProcessor.sendResponse( conId, msg+"\r\n" );

		return null;

	}

	private int getCodeStatus( String code )
	{
		return 0;
	}

	private ArrayList< String > tokenize( String line )
	{
		return null;
	}

	@Override
	public void run()
	{
		NetworkInteractor interactor = mailProcessor.getInteractor();
		String domain = mail.getDomain();
		conId = interactor.initiateConnection( domain );
		mailProcessor.registerSender( conId, this );

	}

	public String getEndString()
	{
		return null;
	}

	@Override
	public MailHelper getHelper()
	{
		// TODO Auto-generated method stub
		return null;
	}

}
