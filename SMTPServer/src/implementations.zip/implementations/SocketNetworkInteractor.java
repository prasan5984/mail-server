package implementations;

import interfaces.NetworkInteractor;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class SocketNetworkInteractor implements NetworkInteractor
{

	private static ServerSocketChannel	srvChannel;
	private static ServerSocket			incomingSocket;
	final public static Charset			CHARACTER_SET	= Charset.forName( "UTF-8" );
	public static String				serverAddress	= "127.0.0.1";
	public static int					serverPort		= 25;
	private OutgoingConnector			outConnector;
	private IncomingConnector			inConnector;
	private List< SocketChannel >		readSockets		= new ArrayList< SocketChannel >();
	private List< SocketChannel >		readOutSockets	= new ArrayList< SocketChannel >();

	public void startServer()
	{

		try
		{
			srvChannel = ServerSocketChannel.open();
			srvChannel.configureBlocking( false );
			incomingSocket = srvChannel.socket();
			InetSocketAddress address = new InetSocketAddress( serverPort );
			incomingSocket.bind( address );
		}
		catch ( IOException e )
		{
			System.out.println( "Unable to start the server on port: " + serverPort );
			e.printStackTrace();
		}

		readSockets = Collections.synchronizedList( readSockets );

		// Incoming Listener
		inConnector = new IncomingConnector();
		MailServer.getExecutorService().submit( inConnector );

		// Outgoing Listener
		outConnector = new OutgoingConnector();
		MailServer.getExecutorService().submit( outConnector );

	}

	public void sendMessage( Object obj, String msg )
	{
		SocketChannel ch = (SocketChannel)obj;

		CharsetEncoder encoder = CHARACTER_SET.newEncoder();

		CharBuffer charBuf = CharBuffer.wrap( msg );
		ByteBuffer byteBuf = null;
		try
		{
			byteBuf = encoder.encode( charBuf );
		}
		catch ( CharacterCodingException e1 )
		{
			e1.printStackTrace();
		}

		if ( ch != null )
		{
			synchronized (ch)
			{
				try
				{
					ch.write( byteBuf );
				}
				catch ( IOException e )
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

	@Override
	public Object initiateConnection( String domain )
	{
		InetAddress ip = null;
		try
		{
			ip = InetAddress.getByName( domain );
		}
		catch ( UnknownHostException e1 )
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		InetSocketAddress inetaddr = new InetSocketAddress( "mailtrap.io", 25 );
		SocketChannel channel = null;
		try
		{
			channel = SocketChannel.open();
			channel.connect( inetaddr );
			channel.configureBlocking( false );
			outConnector.registerChannel( (SocketChannel)channel );
			MailServer.getExecutorService().submit( outConnector );

		}
		catch ( IOException e )
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return channel;

	}

	class NetworkProcessorThread implements Runnable
	{
		private Object	parameter;
		private int		actionType;

		public NetworkProcessorThread( int actType, Object parameter )
		{
			actionType = actType;
			this.parameter = parameter;
		}

		public void run()
		{

			if ( actionType == 0 )
			{
				MailServer.getMailProcessor().onAccept( parameter );

			}
			else if ( actionType == 1 )
			{
				SocketChannel channel = (SocketChannel)parameter;

				CharsetDecoder decoder = CHARACTER_SET.newDecoder();
				ByteBuffer byteBuf = ByteBuffer.allocate( 1024 );

				String msg = "";
				int r;

				while ( true )
				{
					try
					{
						r = channel.read( byteBuf );
						if ( r <= 0 )
						{
							if ( readSockets.contains( channel ) )
								readSockets.remove( channel );

							if ( readOutSockets.contains( channel ) )
								readOutSockets.remove( channel );

							break;
						}

						byteBuf.flip();
						msg = msg + decoder.decode( byteBuf ).toString();
					}
					catch ( CharacterCodingException e )
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
						break;
					}
					catch ( IOException e )
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
						break;
					}
					byteBuf.clear();

				}
				if ( msg != null )
					if ( msg.length() != 0 )
					{
						System.out.println( msg );
						MailServer.getMailProcessor().onRead( channel, msg );
					}
			}

		}
	}

	class IncomingConnector implements Runnable
	{

		Selector	selector;

		IncomingConnector()
		{
			try
			{
				selector = Selector.open();
			}
			catch ( IOException e )
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		@Override
		public void run()
		{
			try
			{

				srvChannel.register( selector, SelectionKey.OP_ACCEPT );

				while ( true )
				{

					selector.select();

					Set selectedKeys = selector.selectedKeys();
					Iterator iterator = selectedKeys.iterator();

					while ( iterator.hasNext() )
					{
						SelectionKey selectionKey = (SelectionKey)iterator.next();
						SocketChannel channel = null;

						if ( ( selectionKey.readyOps() & SelectionKey.OP_ACCEPT ) == SelectionKey.OP_ACCEPT )
						{
							ServerSocketChannel key = (ServerSocketChannel)selectionKey.channel();

							channel = key.accept();

							channel.configureBlocking( false );
							channel.register( selector, SelectionKey.OP_READ );

							NetworkProcessorThread processThread = new NetworkProcessorThread( 0, channel );
							MailServer.getExecutorService().submit( processThread );

							iterator.remove();

						}
						else if ( ( selectionKey.readyOps() & SelectionKey.OP_READ ) == SelectionKey.OP_READ )

						{
							channel = (SocketChannel)selectionKey.channel();

							if ( !readSockets.contains( channel ) )
							{
								readSockets.add( channel );
								NetworkProcessorThread processThread = new NetworkProcessorThread( 1, channel );
								MailServer.getExecutorService().submit( processThread );
							}

							iterator.remove();
						}

					}

				}

			}
			catch ( IOException e )
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	class OutgoingConnector implements Runnable
	{

		Selector	selector;

		OutgoingConnector()
		{
			try
			{
				selector = Selector.open();
			}
			catch ( IOException e )
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		@Override
		public void run()
		{
			try
			{

				while ( true )
				{

					synchronized (selector)
					{
						selector.select( 50 );

						Set selectedKeys = selector.selectedKeys();
						Iterator iterator = selectedKeys.iterator();

						while ( iterator.hasNext() )
						{
							SelectionKey selectionKey = (SelectionKey)iterator.next();
							SocketChannel channel = null;

							/*if ( ( selectionKey.readyOps() & SelectionKey.OP_CONNECT ) == SelectionKey.OP_CONNECT )
							{
								SocketChannel key = (SocketChannel)selectionKey.channel();

								channel = key;

								//channel.configureBlocking( false );
								//channel.register( selector, SelectionKey.OP_READ );
								NetworkProcessorThread processThread = new NetworkProcessorThread( 1, channel );
								MailServer.getExecutorService().submit( processThread );

								iterator.remove();

							}
							else */if ( ( selectionKey.readyOps() & SelectionKey.OP_READ ) == SelectionKey.OP_READ )

							{
								channel = (SocketChannel)selectionKey.channel();

								if ( !readOutSockets.contains( channel ) )
								{
									NetworkProcessorThread processThread = new NetworkProcessorThread( 1, channel );
									MailServer.getExecutorService().submit( processThread );
								}
								iterator.remove();
							}

						}
					}
				}

			}
			catch ( IOException e )
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		public void registerChannel( SocketChannel channel )
		{
			selector.wakeup();
			synchronized (selector)
			{
				try
				{
					//channel.register( selector, SelectionKey.OP_CONNECT );
					channel.register( selector, SelectionKey.OP_READ );
				}
				catch ( ClosedChannelException e )
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

	}

}