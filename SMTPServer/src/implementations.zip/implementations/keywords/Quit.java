package implementations.keywords;

import constants.MailServerConstants;
import implementations.keywords.properties.SMTPProperties;
import interfaces.KeyProperties;
import interfaces.Keyword;
import interfaces.Mail;
import interfaces.MailReceiver;

public class Quit implements Keyword
{

	@Override
	public void process( MailReceiver processor )
	{
		if ( processor.isMailCompletion() )
			processor.processMail( processor.getMail() );

		processor.sendResponse( MailServerConstants.DEFAULT_SUCCESS_CODE + " "
				+ MailServerConstants.CODE_MSG_MAP.get( MailServerConstants.DEFAULT_SUCCESS_CODE ) );
	}

	@Override
	public void successiveProcess( MailReceiver processor )
	{
		// TODO Auto-generated method stub

	}

	@Override
	public String getName()
	{
		return "QUIT";
	}

	@Override
	public KeyProperties getProperties()
	{
		SMTPProperties prop = new SMTPProperties();
		prop.setKeywordName( "QUIT" );
		prop.setMultiOccurence( false );
		prop.setSkipSequenceCheck( true );
		return prop;
	}

	@Override
	public Keyword getClonedObject()
	{
		Quit quit = new Quit();
		return quit;
	}

	@Override
	public String getMailTransaction( Mail mail, String response )
	{
		return "Quit";
	}

	@Override
	public boolean getStatus()
	{
		return true;
	}
}
