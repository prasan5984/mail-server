package implementations.keywords;

import java.util.ArrayList;

import constants.MailServerConstants;
import implementations.SMTPServerHelper;
import implementations.keywords.properties.SMTPProperties;
import interfaces.KeyProperties;
import interfaces.Keyword;
import interfaces.Mail;
import interfaces.MailHelper;
import interfaces.MailReceiver;

public class RcptTo implements Keyword {

	private ArrayList<String> toAddressList;
	private int index;
	private boolean status;

	@Override
	public void process(MailReceiver processor) {
		
		String toUser = processor.getToken(1);
		
		if (toUser == null) {
			// Appropriate Error		
			return;
		}
		
		// check if user exists
		if (!SMTPServerHelper.userExist(toUser)) {
			processor.sendResponse(MailServerConstants.USER_NOT_EXIST
					+ " "
					+ MailServerConstants.CODE_MSG_MAP
							.get(MailServerConstants.USER_NOT_EXIST));
			return;
		}
		
		

		Mail mail = processor.getMail();
		mail.setTo(toUser);
		processor.setMail(mail);

		processor.sendResponse(MailServerConstants.DEFAULT_SUCCESS_CODE
				+ " "
				+ MailServerConstants.CODE_MSG_MAP
						.get(MailServerConstants.DEFAULT_SUCCESS_CODE));

	}

	@Override
	public void successiveProcess(MailReceiver processor) {
		// TODO Auto-generated method stub

	}

	@Override
	public String getName() {
		return "RCPT TO:";
	}

	@Override
	public KeyProperties getProperties() {
		SMTPProperties prop = new SMTPProperties();
		Keyword key = new MailFrom();
		prop.setKeywordName("RCPT TO:");
		prop.setLastKey(key.getName());
		prop.setMultiOccurence(true);
		prop.setSkipSequenceCheck(false);
		return prop;
	}

	@Override
	public Keyword getClonedObject() {
		RcptTo rcptTo = new RcptTo();
		return rcptTo;
	}

	@Override
	public String getMailTransaction(Mail mail, String response) {
		index++;
		if (index >= toAddressList.size() - 1)
			status = true;
		return "RCPT TO:" + toAddressList.get(index);
	}

	@Override
	public boolean getStatus() {
		return status;
	}

}
